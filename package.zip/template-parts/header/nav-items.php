<?php
    wp_nav_menu(array(
        "menu" => "primary",
        "menu_class" => "nav-items-list",
        "container_class" => "nav-items-container gothic"
    ))
;?>